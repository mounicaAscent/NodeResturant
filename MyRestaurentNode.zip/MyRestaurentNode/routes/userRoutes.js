const express = require("express");
const {
  userController,
  updateUserController,
  updatePasswordController,
  resetPasswordController,
  deleteUserController,
} = require("../controllers/userController");
const authMiddleware = require("../middlewares/authMiddleware");
const router = express.Router();

// get user
router.get("/getUser", authMiddleware, userController);
// update  user
router.put("/updateUser", authMiddleware, updateUserController);
// update password

router.post("/updatePassword", authMiddleware, updatePasswordController);

//reset password
router.post("/resetPassword", authMiddleware, resetPasswordController);

//delete user
router.delete("/deleteUser/:userId", authMiddleware, deleteUserController);
module.exports = router;
