const express = require("express");
const authMiddleware = require("../middlewares/authMiddleware");
const {
  createFoodController,
  getAllFoodsController,
  getSingleFoodController,
  getFoodByResturantController,
  updateFoodController,
  deleteFoodId,
  placeOrderController,
} = require("../controllers/foodController");

const router = express.Router();
//create
router.post("/create", authMiddleware, createFoodController);
//getAll
router.get("/getAll", getAllFoodsController);
//getbyID

router.get("/get/:id", authMiddleware, getSingleFoodController);

router.get("/getByResturant/:id", getFoodByResturantController);
//router put
router.put("/update/:id", authMiddleware, updateFoodController);

//delete
router.delete("/delete/:id", authMiddleware, deleteFoodId);

//food order
router.post("/placeOrder", authMiddleware, placeOrderController);

module.exports = router;
