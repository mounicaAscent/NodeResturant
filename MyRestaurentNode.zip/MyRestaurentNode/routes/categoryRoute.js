const express = require("express");
const authMiddleware = require("../middlewares/authMiddleware");
const {
  categoryController,
  getCategoryController,
  updateCategoryController,
} = require("../controllers/categoryController");

const router = express.Router();
router.post("/create", authMiddleware, categoryController);
//get category
router.get("/get", getCategoryController);

//update category
router.put("/update/:id", authMiddleware,  updateCategoryController);
module.exports = router;
