const express = require("express");
const authMiddleware = require("../middlewares/authMiddleware");
const {
  createResturantController,
  getAllResturantsController,
  getResturantByIdController,
  deleteResturantController,
} = require("../controllers/resturentController");
const router = express.Router();

//create resturant post method
router.post("/create", authMiddleware, createResturantController);

// get All resturants - get method
router.get("/getAll", getAllResturantsController);

//get resturant by id - get method
router.get("/get/:id", getResturantByIdController);

//resturant delete
router.delete("/delete/:id", authMiddleware, deleteResturantController);

module.exports = router;
