const foodModel = require("../models/foodModel");

const createFoodController = async (req, res) => {
  try {
    const {
      title,
      description,
      price,
      imageUlr,
      foodTags,
      category,
      code,
      isAvailable,
      resturant,
      rating,
      ratingCount,
    } = req.body;

    if (!title || !description || !price || !resturant) {
      return res.status(404).send({
        success: false, // ✅ fixed
        message: "please provide all fields",
      });
    }

    const newFood = new foodModel({
      title,
      description,
      price,
      imageUlr,
      foodTags,
      category,
      code,
      isAvailable,
      resturant,
      rating,
      ratingCount,
    });

    await newFood.save();

    res.status(201).send({
      success: true,
      message: "new food created successfully",
    });
  } catch (err) {
    console.error("❌ Error while saving food:", err.message);
    return res.status(500).send({
      success: false,
      message: err.message, // ✅ show actual reason for failure
    });
  }
};

const getAllFoodsController = async (req, res) => {
  try {
    const foods = await foodModel.find({});
    if (!foods) {
      return res.status(404).send({
        success: true,
        message: "food are not found",
      });
    }
    res.status(200).send({
      success: true,
      message: "food are fectched successfully",
      totalFoods: foods.length,
      foods,
    });
  } catch (err) {
    console.log(err, "err");
    return res.status(500).send({
      success: false,
      message: err.message,
    });
  }
};

const getSingleFoodController = async (req, res) => {
  try {
    console.log(req.params.foodId);

    const foodId = req.params.id;
    if (!foodId) {
      return res.status(404).send({
        success: false,
        message: "please provide id",
      });
    }
    const food = await foodModel.findById(foodId);
    if (!food) {
      return res.status(404).send({
        success: false,
        message: "food  is not not found",
      });
    }
    res.status(200).send({
      success: true,
      message: "food id is successfully fectched",
    });
  } catch (err) {
    console.log(err);
    return res.status(500).send({
      success: true,
      message: err.message,
    });
  }
};

const getFoodByResturantController = async (req, res) => {
  try {
    console.log(req.params.foodId);

    const resturantId = req.params.id;
    if (!resturantId) {
      return res.status(404).send({
        success: false,
        message: "please provide id",
      });
    }
    const food = await foodModel.findById({ resturant: resturantId });
    if (!food) {
      return res.status(404).send({
        success: false,
        message: "food  is not not found",
      });
    }
    res.status(200).send({
      success: true,
      message: "food id is successfully fectched",
    });
  } catch (err) {
    console.log(err);
    return res.status(500).send({
      success: true,
      message: err.message,
    });
  }
};

const updateFoodController = async (req, res) => {
  try {
    const foodId = req.params.id;
    console.log(foodId, "foodId");
    if (!foodId) {
      return res.status(404).send({
        success: false,
        message: "please provide id ",
      });
    }
    const food = await foodModel.findByIdAndUpdate(foodId);
    console.log(food, "food");

    if (!food) {
      return res.status(404).send({
        success: false,
        message: "error in update id",
      });
    }
    const {
      title,
      description,
      price,
      imageUrl,
      foodTags,
      category,
      code,
      isAvailable,
      resturant,
      rating,
      ratingCount,
    } = req.body;
    const updatedFood = await foodModel.findByIdAndUpdate(
      foodId,
      {
        title,
        description,
        price,
        imageUrl,
        foodTags,
        category,
        code,
        isAvailable,
        resturant,
        rating,
        ratingCount,
      },
      { new: true }
    );
    res.status(200).send({
      success: true,
      message: "id updated successfully",
      updatedFood,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).send({
      success: false,
      message: err.message,
    });
  }
};

const deleteFoodId = async (req, res) => {
  try {
    const resturantId = req.params.id;
    console.log(resturantId, "resturantId");
    if (!resturantId) {
      return res.status(404).send({
        success: false,
        message: "id is not found",
      });
    }
    await foodModel.findByIdAndDelete(resturantId);
    res.status(200).send({
      success: true,
      message: "id is deleted successfully ",
    });
  } catch (err) {
    console.log(err);
    return res.status(500).send({
      success: false,
      message: err.message,
    });
  }
};


const placeOrderController=()=>{}

module.exports = {
  createFoodController,
  getAllFoodsController,
  getSingleFoodController,
  getFoodByResturantController,
  updateFoodController,
  deleteFoodId,
  placeOrderController
};
