const categoryModel = require("../models/categoryModel");

const categoryController = async (req, res) => {
  try {
    const { title, imageUrl } = req.body;
    if (!title || imageUrl) {
      return res.status(404).send({
        success: false,
        message: "please provide all field",
      });
    }
    const newCategory = new categoryModel({ title, imageUrl });
    await newCategory.save();
    res.status(201).send({
      success: true,
      message: "category created  successfully ",
    });
  } catch (err) {
    console.log(err, "something went wrong");
    return res.status(500).send({
      success: false,
      message: "category failed",
    });
  }
};

const getCategoryController = async (req, res) => {
  try {
    const categorys = await categoryModel.find({});
    if (!categorys) {
      return res.status(404).send({
        success: false,
        message: "no category found",
      });
    }
    res.status(200).send({
      success: true,
      message: "category fetched successfully",
      totalCat: categorys.length,
      categorys,
    });
  } catch {
    console.log(err, "something weent wrong");
    return res.status(500).send({
      success: false,
      message: "get category failed",
    });
  }
};

const updateCategoryController = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, imageUrl } = req.body;
    const updateCategory = await categoryModel.findByIdAndUpdate(
      id,
      { title, imageUrl },
      { new: true }
    );
    if(!updateCategory){
        return res.status(404).send({
            success:false,
            message:"no categories found"
        })
    }
    res.status(200).send({
        success:true,
        message:"updated successfully"
    })
  } catch (err) {
    console.log(err, "somenthing went wrong");
    return res.status(500).send({
      success: true,
      message: "failed update",
    });
  }
};
module.exports = {
  categoryController,
  getCategoryController,
  updateCategoryController,
};
