const testUserController = (req, res) => {
  try {
    res.status(200).send({
      success: true,
      Message: "Test Controller is working fine",
    });
  } catch (err) {
    console.log("Error in test user controller", err);
  }
};
module.exports = { testUserController };
