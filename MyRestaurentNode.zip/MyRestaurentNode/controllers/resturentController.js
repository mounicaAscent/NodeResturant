const resturantModel = require("../models/restarentModel");
const createResturantController = async (req, res) => {
  try {
    const {
      title,
      imageUrl,
      foods,
      pickup,
      delivery,
      isOpen,
      logoUrl,
      rating,
      ratingCount,
      code,
      coords,
    } = req.body;
    if (!title || !coords) {
      return res.status(400).send({
        success: false,
        message: "Title and Coords are required",
      });
    }
    const newResturant = new resturantModel({
      title,
      imageUrl,
      foods,
      pickup,
      delivery,
      isOpen,
      logoUrl,
      rating,
      ratingCount,
      code,
      coords,
    });
    await newResturant.save();
    console.log(newResturant, "newResturants");

    return res.status(201).send({
      success: true,
      message: "Resturant created successfully",
      //   newResturant,
    });
  } catch (err) {
    console.log("Error in create resturant controller", err);
    return res.status(500).send({
      success: false,
      message: "Error in create resturant controller",
    });
  }
};

const getAllResturantsController = async (req, res) => {
  try {
    const resturants = await resturantModel.find({});
    if (!resturants) {
      return res.status(404).send({
        success: false,
        message: "No resturants found",
      });
    }
    res.status(200).send({
      success: true,
      message: "Resturants fetched successfully",
      resturants,
    });
  } catch (err) {
    console.log("Error in get all resturants controller", err);
    return res.status(500).send({
      success: false,
      message: "Error in get all resturants controller",
    });
  }
};

const getResturantByIdController = async (req, res) => {
  try {
    const resturentId = req.params.id;
    if (!resturentId) {
      return res.status(400).send({
        success: false,
        message: "Resturant ID is required",
      });
    }
    const resturant = await resturantModel.findById(resturentId);
    if (!resturant) {
      return res.status(404).send({
        success: false,
        message: "no resturant found with this id",
        // resturant,}
      });
    }
    res.status(200).send({
      success: true,
      message: "ResturantId fetched successfully",
      resturant,
    });
  } catch (err) {
    console.log("Error in get resturant by id controller", err);
    return res.status(500).send({
      success: false,
      message: "Error in get resturant by id controller",
    });
  }
};

const deleteResturantController = async (req, res) => {
  try {
    const resturantId = req.params.id;
    if (!resturantId) {
      return res.status(404).send({
        success: false,
        message: "no resturant found ",
      });
    }
    await resturantModel.findByIdAndDelete(resturantId);
    res.status(200).send({
      success: true,
      message: "restaurent by id is successfully delelted",
    });
  } catch (err) {
    console.log(err, "delete resturant failed");
    return res.status(500).send({
      success: false,
      message: "delete failed",
    });
  }
};
module.exports = {
  createResturantController,
  getAllResturantsController,
  getResturantByIdController,
  deleteResturantController,
};
