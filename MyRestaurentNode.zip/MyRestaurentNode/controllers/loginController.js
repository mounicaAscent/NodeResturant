const userModel = require("../models/userModel");

const loginController = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(500).send({
        success: false,
        message: "Please provide all required fields",
      });
    }
    const user = await userModel.findOne({ email });
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "User not found please register",
      });
    }
    res.status(200).send({
      success: true,
      message: "Login successful",
      user,
    });
  } catch (err) {
    console.log("Error in login controller", err);
    res.status(500).send({
      success: false,
      message: "Error in Login",
    });
  }
};
module.exports = { loginController };
