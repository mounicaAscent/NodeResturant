const { bgCyan } = require("colors");
const userModel = require("../models/userModel");
const userController = async (req, res) => {
  try {
    // Use the correct property from middleware
    console.log("req.userId:", req.userId);
    const user = await userModel.findOne({ _id: req.userId });
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "User not found",
      });
    }
    user.password = undefined;
    res.status(200).send({
      success: true,
      message: "User fetched successfully",
      // user,
    });
  } catch (err) {
    console.log(err, "something went error");
    res.status(500).send({
      success: false,
      message: "Error in user controller",
    });
  }
};

const updateUserController = async (req, res) => {
  try {
    console.log("req.userId:", req.userId);
    const user = await userModel.findById(req.userId);
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "User not found",
      });
    }
    //update
    const { userName, address, phone } = req.body;
    if (userName) user.userName = userName;
    if (address) user.address = address;
    if (phone) user.phone = phone;

    await user.save();
    res.status(200).send({
      success: true,
      message: "User Updated Successfully",
      // user,
    });
  } catch (err) {
    console.log(err, "update Failed");
    res.status(500).send({
      success: false,
      message: "Error in Update User Controller",
    });
  }
};

const updatePasswordController = async (req, res) => {
  try {
    const user = await userModel.findById(req.userId);
    if (!user) {
      return res.status(400).send({
        success: false,
        message: "User not found",
      });
    }

    return res.status(200).send({
      success: true,
      message: "Password updated successfully",
    });
  } catch (err) {
    console.log(err, "update password failed");
    return res.status(500).send({
      success: false,
      message: "Error in update password controller",
    });
  }
};

const resetPasswordController = async (req, res) => {
  try {
    const { email, password, answer } = req.body;
    if (!email || !password || !answer) {
      return res.status(400).send({
        success: false,
        message: "Please provide all required fields",
      });
    }
    const user = await userModel.findOne({
      email,
      answer,
    });
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "Wrong email or answer",
      });
    }
    const salt = await bcrypt.genSaltSync(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);
    user.password = hashedPassword;
    await user.save();
    return res.status(200).send({
      success: true,
      message: "Password reset successfully",
    });
  } catch (err) {
    console.log(err, "reset password failed");
    return res.status(500).send({
      success: false,
      message: "Error in reset password controller",
      error,
    });
  }
};

const deleteUserController = async (req, res) => {
  try {
    console.log("req.userId:", req.params.userId);
    await userModel.findByIdAndDelete(req.params.userId);

    return res.status(200).send({
      success: true,
      message: "User deleted successfully",
    });
  } catch (err) {
    console.log(err, "delete user failed");
    return res.status(500).send({
      success: false,
      message: "Error in delete user controller",
    });
  }
};
module.exports = {
  userController,
  updateUserController,
  updatePasswordController,
  resetPasswordController,
  deleteUserController,
};
