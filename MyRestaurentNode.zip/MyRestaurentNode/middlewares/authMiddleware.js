const JWT = require("jsonwebtoken");

module.exports = async (req, res, next) => {
  try {
    const authHeader = req.headers["authorization"];

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).send({
        success: false,
        message: "No token provided or invalid format",
      });
    }

    const token = authHeader.split(" ")[1];
    console.log("Token received:", token);

    // ✅ Use comma, not dot
    JWT.verify(token, process.env.JWT_SECRET, (err, decode) => {
      if (err) {
        console.log("JWT verification failed:", err.message);
        return res.status(401).send({
          success: false,
          message: "Unauthorized access",
        });
      } else {
        console.log("Decoded token:", decode);
        req.userId = decode.id;
        next();
      }
    });
  } catch (err) {
    console.log("Error in auth middleware", err);
    res.status(500).send({
      success: false,
      message: "Error in auth middleware",
    });
  }
};
