const data = {
  title: "Green Spoon",
  imageUrl: "https://www.greenspoon.com/images/green-spoon-main.jpg",
  foods: [
    { name: "Avocado Salad", price: 9.99, isVegetarian: true },
    { name: "Grilled Chicken Wrap", price: 11.99, isVegetarian: false },
  ],
  pickup: true,
  delivery: true,
  isOpen: true,
  logoUrl: "https://www.greenspoon.com/images/logo.png",
  rating: 4.6,
  ratingCount: "324",
  code: "GSPN465",
  coords: {
    id: "co123abc",
    latitude: 37.7749,
    longitude: -122.4194,
    longitudeDelta: 0.02,
    latitudeDelta: 0.01,
    address: "789 Mission St, San Francisco, CA",
    title: "Green Spoon Downtown",
  },
};
